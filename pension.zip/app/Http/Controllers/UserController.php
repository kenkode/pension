<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['users']= User::all();

      //$data = User::select('userId','userName')
        //    ->get();

    //return $users;
    return view('users.index',$data);
    
    }

   

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //User::create($request->all());

        $user = new User;
        $insert=$user->create_user($request->name,$request->email,$request->password,$request->role,$request->payroll_no);    

        $data['status'] = 'User added!';
        $data['status_class'] = 'alert-success';
        return redirect('users')->with($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit( User $user)
    {
         $data['user'] = $user;

         
        return view('users.edit',$data);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
       
         
        $update=$user->update_staff($request->id,$request->name,$request->email,$request->role,$request->payroll_no);   

        $data['status'] = 'User updated!';
        $data['status_class'] = 'alert-success';
        return redirect('users')->with($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       
        user::find($id)->delete();
        $data['status'] = 'User deleted!';
        $data['status_class'] = 'alert-success';

        return redirect('users')->with($data);
    }

    public function deductions()
    {
        $data['users']= User::all();

      
    return view('deductions.employee',$data);
    
    }

    public static function payroll_name($payroll_no)
    {
        
      $data = User::select('*')
               ->where('payroll_no', '=', $payroll_no)  
               ->get();

    return $data[0]->name;
    //return view('deductions.employee',$data);
    
    }
}
